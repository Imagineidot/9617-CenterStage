package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

/**
 * This file contains an example of an iterative (Non-Linear) "OpMode".
 * An OpMode is a 'program' that runs in either the autonomous or the teleop period of an FTC match.
 * The names of OpModes appear on the menu of the FTC Driver Station.
 * When an selection is made from the menu, the corresponding OpMode
 * class is instantiated on the Robot Controller and executed.
 * <p>
 * This particular OpMode just executes a basic Tank Drive Teleop for a two wheeled robot
 * It includes all the skeletal structure that all iterative OpModes contain.
 * <p>
 * Use Android Studios to Copy this Class, and Paste it into your team's code folder with a new name.
 * Remove or comment out the @Disabled line to add this opmode to the Driver Station OpMode list
 */

@TeleOp(name = "MechnamOpMode", group = "Iterative Opmode")
public class MechnamOp extends OpMode {
    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor leftfrontDrive = null;
    private DcMotor rightfrontDrive = null;
    private DcMotor rightbackDrive = null;
    private DcMotor leftbackDrive = null;
    private DcMotor lift = null;


    public Servo Servo = null;


    public static final double MID_SERVO = 0.5;
    public static final double ARM_UP_POWER = 1.0;
    public static final double ARM_DOWN_POWER = -1.0;
    /*Code to run ONCE when the driver hits INIT*/

    @Override
    public void init() {
        telemetry.addData("Status", "Initialized");

        // Initialize the hardware variables. Note that the strings used here as parameters
        // to 'get' must correspond to the names assigned during t-ofhe robot configuration
        // step (using the FTC Robot Controller app on the phone).
        leftfrontDrive = hardwareMap.get(DcMotor.class, "left_front_drive");
        rightfrontDrive = hardwareMap.get(DcMotor.class, "right_front_drive");
        leftbackDrive = hardwareMap.get(DcMotor.class, "left_back_drive");
        rightbackDrive = hardwareMap.get(DcMotor.class, "right_back_drive");
        lift = hardwareMap.get(DcMotor.class, "lift");


        Servo = hardwareMap.get(Servo.class, "Servo");


        // Most robots need the motor on one side to be reversed to drive forward
        // Reverse the motor that runs backwards when connected directly to the battery
        leftfrontDrive.setDirection(DcMotor.Direction.REVERSE);
        leftbackDrive.setDirection(DcMotor.Direction.REVERSE);
        rightfrontDrive.setDirection(DcMotor.Direction.FORWARD);
        rightbackDrive.setDirection(DcMotor.Direction.FORWARD);
        lift.setDirection(DcMotor.Direction.FORWARD);

        // Tell the driver that initialization is complete.
        telemetry.addData("Status", "Initialized");
    }

    /*
     * Code to run REPEATEDLY after the driver hits INIT, but before they hit PLAY
     */
    @Override
    public void init_loop() {


    }

    /*
     * Code to run ONCE when the driver hits PLAY
     */
    @Override
    public void start() {
        runtime.reset();
    }

    /*
     * Code to run REPEATEDLY after the driver hits PLAY but before they hit STOP
     */
    @Override
    public void loop() {
        Servo.setPosition(gamepad1.left_trigger);

        telemetry.addData("Trigger", "%2.5f", gamepad1.left_trigger);
        telemetry.update();

        if (gamepad1.dpad_up) {
        }


        double MAX_SPEED = 1.0;

        double speed = 0.5;

        double dz_threshold = 0.1;
        double x = -gamepad1.left_stick_x;
        double y = gamepad1.left_stick_y;


        if (Math.abs(x) < dz_threshold) {
            x = 0.0;
        }

        if (Math.abs(y) < dz_threshold) {
            y = 0.0;
        }

        if (gamepad1.left_stick_button) {
            speed = 1.0;
        }
        if (gamepad1.right_bumper) {
            speed = 0.1;
        }

        mecanumDrive_Cartesian(x, y, -gamepad1.right_stick_x, speed);


        if (gamepad1.x) {
            lift.setPower(1.0);
        } else if (gamepad1.y) {
            lift.setPower(-0.5);
        } else{
            lift.setPower(0.0);
        }




        /*if (gamepad1.dpad_right) {
            mecanumDrive_Cartesian(1.0,0.0,0.0);
        }
        else if (gamepad1.dpad_left) {
            mecanumDrive_Cartesian(-1.0,0.0,0.0);

        }
        else{
        mecanumDrive_Cartesian(0.0,0.0,0.0);
        }*/

    }

    /*
     * Code to run ONCE after the driver hits STOP
     */
    @Override
    public void stop() {
    }

    public void mecanumDrive_Cartesian(double x, double y, double rotation, double speed) {
        double wheelSpeeds[] = new double[4];


        wheelSpeeds[0] = -x + y - rotation;
        wheelSpeeds[1] = x + y + rotation;
        wheelSpeeds[2] =x + y - rotation;
        wheelSpeeds[3] = -x + y + rotation;

        normalize(wheelSpeeds);

        rightfrontDrive.setPower(wheelSpeeds[0] * speed);
        leftfrontDrive.setPower(wheelSpeeds[1] * speed);
        rightbackDrive.setPower(wheelSpeeds[2] * speed);
        leftbackDrive.setPower(wheelSpeeds[3] * speed);
    }   //mecanumDrive_Cartesian

    private void normalize(double[] wheelSpeeds) {
        double maxMagnitude = Math.abs(wheelSpeeds[0]);

        for (int i = 1; i < wheelSpeeds.length; i++) {
            double magnitude = Math.abs(wheelSpeeds[i]);

            if (magnitude > maxMagnitude) {
                maxMagnitude = magnitude;
            }
        }

        if (maxMagnitude > 1.0) {
            for (int i = 0; i < wheelSpeeds.length; i++) {
                wheelSpeeds[i] /= maxMagnitude;
            }
        }
    }   //normalize

}
