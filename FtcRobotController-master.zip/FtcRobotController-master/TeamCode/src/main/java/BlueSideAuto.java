

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.util.Range;

/**
 * This file contains an example of an iterative (Non-Linear) "OpMode".
 * An OpMode is a 'program' that runs in either the autonomous or the teleop period of an FTC match.
 * The names of OpModes appear on the menu of the FTC Driver Station.
 * When an selection is made from the menu, the corresponding OpMode
 * class is instantiated on the Robot Controller and executed.
 *
 * This particular OpMode just executes a basic Tank Drive Teleop for a two wheeled robot
 * It includes all the skeletal structure that all iterative OpModes contain.
 *
 * Use Android Studios to Copy this Class, and Paste it into your team's code folder with a new name.
 * Remove or comment out the @Disabled line to add this opmode to the Driver Station OpMode list
 */

@Autonomous(name="SimpleAuto", group="Iterative Opmode")
public class BlueSideAuto extends LinearOpMode
{
    // Declare OpMode members.
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor leftfrontDrive = null;
    private DcMotor rightfrontDrive = null;
    private DcMotor rightbackDrive = null;
    private DcMotor leftbackDrive = null;



    static final double     COUNTS_PER_MOTOR_REV    = 28.0 ;    // eg: TETRIX Motor Encoder
    static final double     DRIVE_GEAR_REDUCTION    = 40.0 ;     // This is < 1.0 if geared UP
    static final double     WHEEL_DIAMETER_INCHES   = 4.0 ;     // For figuring circumference
    static final double     COUNTS_PER_INCH         = (COUNTS_PER_MOTOR_REV * DRIVE_GEAR_REDUCTION) / (WHEEL_DIAMETER_INCHES * 3.1415);
    static final double     DRIVE_SPEED             = 0.6;
    /*
     * Code to run ONCE when the driver hits INIT
     */
    @Override
    public void runOpMode() {
        telemetry.addData("Status", "Initialized");

        // Initialize the hardware variables. Note that the strings used here as parameters
        // to 'get' must correspond to the names assigned during t-ofhe robot configuration
        // step (using the FTC Robot Controller app on the phone).
        leftfrontDrive = hardwareMap.get(DcMotor.class, "left_front_drive");
        rightfrontDrive = hardwareMap.get(DcMotor.class, "right_front_drive");
        leftbackDrive = hardwareMap.get(DcMotor.class, "left_back_drive");
        rightbackDrive = hardwareMap.get(DcMotor.class, "right_back_drive");

// Most robots need the motor on one side to be reversed to drive forward
        // Reverse the motor that runs backwards when connected directly to the battery
        leftfrontDrive.setDirection(DcMotor.Direction.FORWARD);
        leftbackDrive.setDirection(DcMotor.Direction.FORWARD);
        rightfrontDrive.setDirection(DcMotor.Direction.REVERSE);
        rightbackDrive.setDirection(DcMotor.Direction.REVERSE);

        // Tell the driver that initialization is complete.
        telemetry.addData("Status", "Initialized");
        waitForStart();

        move_forward(20.0);

        /*runtime.reset();
        while (opModeIsActive() && (runtime.seconds() < 3.5)) {
            telemetry.addData("Path", "Leg 1: %2.5f S Elapsed", runtime.seconds());
            telemetry.update();*/
        //}


    }


    void move_forward(double inches){



        rightfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        int newRightTarget = (int)(inches * COUNTS_PER_INCH);
        rightfrontDrive.setTargetPosition(newRightTarget);
        leftfrontDrive.setTargetPosition(newRightTarget);
        rightbackDrive.setTargetPosition(newRightTarget);
        leftbackDrive.setTargetPosition(newRightTarget);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        rightfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        leftfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        rightbackDrive.setPower(Math.abs(DRIVE_SPEED));
        leftbackDrive.setPower(Math.abs(DRIVE_SPEED));
        while(opModeIsActive() && rightfrontDrive.isBusy() && leftfrontDrive.isBusy()){

        }

        while(opModeIsActive() && leftfrontDrive.isBusy()){

        }

        while(opModeIsActive() && rightbackDrive.isBusy()){

        }

        while(opModeIsActive() && leftbackDrive.isBusy()){

        }


        rightfrontDrive.setPower(0.0);
        leftfrontDrive.setPower(0.0);
        rightbackDrive.setPower(0.0);
        leftbackDrive.setPower(0.0);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

    }


    void move_backward(double inches){



        rightfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        int newRightTarget = (int)(-inches * COUNTS_PER_INCH);
        rightfrontDrive.setTargetPosition(newRightTarget);
        leftfrontDrive.setTargetPosition(newRightTarget);
        rightbackDrive.setTargetPosition(newRightTarget);
        leftbackDrive.setTargetPosition(newRightTarget);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        rightfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        leftfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        rightbackDrive.setPower(Math.abs(DRIVE_SPEED));
        leftbackDrive.setPower(Math.abs(DRIVE_SPEED));
        while(opModeIsActive() && rightfrontDrive.isBusy()){

        }

        while(opModeIsActive() && leftfrontDrive.isBusy()){

        }

        while(opModeIsActive() && rightbackDrive.isBusy()){

        }

        while(opModeIsActive() && leftbackDrive.isBusy()){

        }


        rightfrontDrive.setPower(0.0);
        leftfrontDrive.setPower(0.0);
        rightbackDrive.setPower(0.0);
        leftbackDrive.setPower(0.0);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

    }

    void move_right(double inches){



        rightfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        int newRightTarget = (int)(inches * COUNTS_PER_INCH);
        rightfrontDrive.setTargetPosition(-newRightTarget);
        leftfrontDrive.setTargetPosition(newRightTarget);
        rightbackDrive.setTargetPosition(newRightTarget);
        leftbackDrive.setTargetPosition(-newRightTarget);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        rightfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        leftfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        rightbackDrive.setPower(Math.abs(DRIVE_SPEED));
        leftbackDrive.setPower(Math.abs(DRIVE_SPEED));
        while(opModeIsActive() && rightfrontDrive.isBusy()){

        }

        while(opModeIsActive() && leftfrontDrive.isBusy()){

        }

        while(opModeIsActive() && rightbackDrive.isBusy()){

        }

        while(opModeIsActive() && leftbackDrive.isBusy()){

        }


        rightfrontDrive.setPower(0.0);
        leftfrontDrive.setPower(0.0);
        rightbackDrive.setPower(0.0);
        leftbackDrive.setPower(0.0);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

    }

    void move_left(double inches){



        rightfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        int newRightTarget = (int)(inches * COUNTS_PER_INCH);
        rightfrontDrive.setTargetPosition(newRightTarget);
        leftfrontDrive.setTargetPosition(-newRightTarget);
        rightbackDrive.setTargetPosition(-newRightTarget);
        leftbackDrive.setTargetPosition(newRightTarget);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        rightfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        leftfrontDrive.setPower(Math.abs(DRIVE_SPEED));
        rightbackDrive.setPower(Math.abs(DRIVE_SPEED));
        leftbackDrive.setPower(Math.abs(DRIVE_SPEED));
        while(opModeIsActive() && rightfrontDrive.isBusy()){

        }

        while(opModeIsActive() && leftfrontDrive.isBusy()){

        }

        while(opModeIsActive() && rightbackDrive.isBusy()){

        }

        while(opModeIsActive() && leftbackDrive.isBusy()){

        }


        rightfrontDrive.setPower(0.0);
        leftfrontDrive.setPower(0.0);
        rightbackDrive.setPower(0.0);
        leftbackDrive.setPower(0.0);

        rightfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftfrontDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftbackDrive.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

    }


}




